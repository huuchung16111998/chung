package com.smile.studio.resoucemanager.network.request

import com.google.gson.annotations.SerializedName

class ProfileRequest(@SerializedName("id") val uid: Int)