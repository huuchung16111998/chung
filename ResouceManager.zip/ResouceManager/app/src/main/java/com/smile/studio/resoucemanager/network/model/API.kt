package com.smile.studio.resoucemanager.network.model

class API {

    companion object {
        val HOST = "http://i-com.vn/"
    }
}